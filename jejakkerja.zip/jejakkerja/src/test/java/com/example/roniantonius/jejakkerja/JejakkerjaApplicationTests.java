package com.example.roniantonius.jejakkerja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JejakkerjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
